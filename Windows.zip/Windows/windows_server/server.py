#注释大王
import asyncio
import websockets
import sqlite3
import json
import os
import socket
import threading
import requests
import webbrowser
import sys
import time
import atexit
import random
from flask import Flask, request, jsonify, send_from_directory, redirect
from datetime import datetime

# 尝试导入CORS
try:
    from flask_cors import CORS
    CORS_AVAILABLE = True
except ImportError:
    CORS_AVAILABLE = False
    print("警告: flask_cors 未安装，建议运行: pip install flask-cors")

# ===== 配置 =====
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB限制
MAX_AVATAR_SIZE = 2 * 1024 * 1024  # 头像2MB限制
UID_LENGTH = 8  # UID长度，例如 12345678

try:
    with open("config.json", "r", encoding="utf-8") as f:
        CONFIG = json.load(f)
except Exception as e:
    print(f"读取配置文件失败: {e}")
    print("请确保 config.json 文件存在且格式正确")
    sys.exit(1)

SERVER_NAME = CONFIG.get("server_name", "我的聊天室")
SERVER_DESCRIPTION = CONFIG.get("description", "一个热闹的聊天室")
WS_PORT = CONFIG.get("ws_port", 8765)
HTTP_PORT = CONFIG.get("http_port", 5000)
LOBBY_URL = CONFIG.get("lobby_url", "http://localhost:8000/register")

# ===== 目录 =====
os.makedirs("data", exist_ok=True)
os.makedirs("uploads", exist_ok=True)
os.makedirs("emojis", exist_ok=True)
os.makedirs("avatars", exist_ok=True)
os.makedirs("logs", exist_ok=True)

# ===== 获取IP（智能检测）=====
def get_local_ip():
    """智能获取本机公网IP，优先从配置读取，其次自动检测"""
    # 如果配置文件里有 public_ip，优先使用
    if CONFIG.get("public_ip"):
        return CONFIG.get("public_ip")
    
    # 否则自动检测
    try:
        # 方法1：通过请求外部服务获取公网IP
        import requests
        ip = requests.get('http://api.ipify.org', timeout=3).text
        return ip
    except:
        try:
            # 方法2：通过socket获取本机IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(3)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"

SERVER_IP = get_local_ip()

# ===== 生成纯数字UID =====
def generate_numeric_uid():
    """生成指定长度的纯数字UID"""
    min_val = 10 ** (UID_LENGTH - 1)
    max_val = (10 ** UID_LENGTH) - 1
    return str(random.randint(min_val, max_val))

def generate_unique_uid(cursor):
    """生成唯一的纯数字UID"""
    while True:
        uid = generate_numeric_uid()
        cursor.execute("SELECT uid FROM users WHERE uid=?", (uid,))
        if not cursor.fetchone():
            return uid

# ===== 数据库管理器 =====
class DatabaseManager:
    def __init__(self):
        self.init_users_db()
        self.init_messages_db()
    
    def init_users_db(self):
        """初始化用户数据库"""
        conn = sqlite3.connect("data/users.db", check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users(
            uid TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            avatar TEXT,
            created_at INTEGER,
            last_login INTEGER
        )
        """)
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS username_history(
            uid TEXT,
            old_username TEXT,
            new_username TEXT,
            changed_at INTEGER,
            FOREIGN KEY(uid) REFERENCES users(uid)
        )
        """)
        
        conn.commit()
        conn.close()
        print("用户数据库初始化成功")
    
    def init_messages_db(self):
        """初始化消息数据库"""
        conn = sqlite3.connect("data/messages.db", check_same_thread=False)
        cursor = conn.cursor()
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uid TEXT,
            username TEXT,
            data TEXT,
            timestamp INTEGER
        )
        """)
        
        conn.commit()
        conn.close()
        print("消息数据库初始化成功")
    
    def get_users_connection(self):
        conn = sqlite3.connect("data/users.db", check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn
    
    def get_messages_connection(self):
        conn = sqlite3.connect("data/messages.db", check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

db_manager = DatabaseManager()

# ===== 大厅注册相关函数 =====
def register_lobby():
    """注册到大厅服务器"""
    try:
        print(f"正在注册到大厅: {LOBBY_URL}")
        response = requests.post(LOBBY_URL, json={
            "name": SERVER_NAME,
            "description": SERVER_DESCRIPTION,
            "ip": SERVER_IP,
            "port": WS_PORT,
            "http_port": HTTP_PORT
        }, timeout=3)
        print(f"注册大厅响应: {response.status_code} - {response.text}")
        return True
    except Exception as e:
        print(f"注册大厅失败: {e}")
        return False

def heartbeat_loop():
    """定期向大厅发送心跳"""
    heartbeat_url = LOBBY_URL.replace('/register', '/heartbeat')
    while True:
        time.sleep(25)
        try:
            response = requests.post(heartbeat_url, 
                                    json={"ip": SERVER_IP, "port": WS_PORT}, 
                                    timeout=2)
            if response.status_code == 200:
                pass
        except:
            pass

def unregister_from_lobby():
    """从大厅注销"""
    try:
        unregister_url = LOBBY_URL.replace('/register', '/unregister')
        response = requests.post(unregister_url, 
                                json={"ip": SERVER_IP, "port": WS_PORT}, 
                                timeout=2)
        if response.status_code == 200:
            print("已从大厅注销")
    except Exception as e:
        print(f"注销失败: {e}")

# 注册退出时的注销函数
atexit.register(unregister_from_lobby)

# ===== Flask =====
app = Flask(__name__)

if CORS_AVAILABLE:
    CORS(app, supports_credentials=True)

# 创建默认头像
def create_default_avatar():
    default_avatar_path = os.path.join("avatars", "default.png")
    if not os.path.exists(default_avatar_path):
        try:
            from PIL import Image, ImageDraw
            img = Image.new('RGB', (128, 128), color='#5865f2')
            draw = ImageDraw.Draw(img)
            draw.ellipse([44, 44, 84, 84], fill='white')
            img.save(default_avatar_path)
            print("默认头像已创建")
        except ImportError:
            print("PIL未安装，创建空白头像")
            with open(default_avatar_path, 'wb') as f:
                f.write(b'')
        except Exception as e:
            print(f"创建默认头像失败: {e}")

create_default_avatar()

# ===== Flask 路由 =====
@app.route("/chat")
def chat_redirect():
    user_agent = request.headers.get('User-Agent', '').lower()
    mobile_keywords = ['mobile', 'android', 'iphone', 'ipad', 'ipod', 'phone', 'tablet']
    is_mobile = any(keyword in user_agent for keyword in mobile_keywords)
    
    if is_mobile:
        return redirect("/mobile.html")
    else:
        return redirect("/chat.html")

@app.route("/info")
def server_info():
    return jsonify({
        "name": SERVER_NAME,
        "description": SERVER_DESCRIPTION,
        "ip": SERVER_IP,
        "ws_port": WS_PORT,
        "http_port": HTTP_PORT
    })

@app.route("/register", methods=["POST", "OPTIONS"])
def register():
    if request.method == "OPTIONS":
        return "", 200
    
    conn = db_manager.get_users_connection()
    cursor = conn.cursor()
    try:
        data = request.json
        username = data["username"]
        password = data["password"]
        
        cursor.execute("SELECT uid FROM users WHERE username=?", (username,))
        if cursor.fetchone():
            return {"status": "fail", "error": "用户名已存在"}, 400
        
        uid = generate_unique_uid(cursor)
        timestamp = int(time.time())
        
        cursor.execute("""
            INSERT INTO users (uid, username, password, avatar, created_at, last_login) 
            VALUES (?, ?, ?, ?, ?, ?)
        """, (uid, username, password, None, timestamp, timestamp))
        
        conn.commit()
        print(f"用户注册成功: {username} (UID: {uid})")
        return {"status": "ok", "uid": uid}
        
    except Exception as e:
        print(f"注册失败: {e}")
        return {"status": "fail", "error": str(e)}, 500
    finally:
        conn.close()

@app.route("/login", methods=["POST", "OPTIONS"])
def login():
    if request.method == "OPTIONS":
        return "", 200
    
    conn = db_manager.get_users_connection()
    cursor = conn.cursor()
    try:
        data = request.json
        login_id = data["username"]
        password = data["password"]
        
        cursor.execute("""
            SELECT uid, username FROM users 
            WHERE (uid=? OR username=?) AND password=?
        """, (login_id, login_id, password))
        
        user = cursor.fetchone()
        if user:
            cursor.execute("UPDATE users SET last_login=? WHERE uid=?", 
                          (int(time.time()), user[0]))
            conn.commit()
            print(f"用户登录成功: {user[1]} (UID: {user[0]})")
            return {"status": "ok", "uid": user[0], "username": user[1]}
        else:
            print(f"登录失败: {login_id}")
            return {"status": "fail", "error": "用户名/UID或密码错误"}, 401
            
    except Exception as e:
        print(f"登录错误: {e}")
        return {"status": "fail", "error": str(e)}, 500
    finally:
        conn.close()

# ===== 修改用户名 =====
@app.route("/change_username", methods=["POST", "OPTIONS"])
def change_username():
    if request.method == "OPTIONS":
        return "", 200
    
    conn = db_manager.get_users_connection()
    cursor = conn.cursor()
    try:
        data = request.json
        uid = data.get("uid")
        new_username = data.get("new_username")
        password = data.get("password")
        
        if not uid or not new_username or not password:
            return {"status": "fail", "error": "参数不完整"}, 400
        
        # 验证用户
        cursor.execute("SELECT username, password FROM users WHERE uid=?", (uid,))
        user = cursor.fetchone()
        if not user:
            return {"status": "fail", "error": "用户不存在"}, 404
        
        # 验证密码
        if user[1] != password:
            return {"status": "fail", "error": "密码错误"}, 401
        
        # 检查新用户名是否已被使用
        cursor.execute("SELECT uid FROM users WHERE username=? AND uid!=?", 
                      (new_username, uid))
        if cursor.fetchone():
            return {"status": "fail", "error": "用户名已存在"}, 400
        
        # 记录旧用户名
        old_username = user[0]
        timestamp = int(time.time())
        
        # 更新用户名
        cursor.execute("UPDATE users SET username=? WHERE uid=?", 
                      (new_username, uid))
        
        # 记录历史
        try:
            cursor.execute("""
                INSERT INTO username_history (uid, old_username, new_username, changed_at)
                VALUES (?, ?, ?, ?)
            """, (uid, old_username, new_username, timestamp))
        except:
            # 如果没有历史表，忽略
            pass
        
        conn.commit()
        print(f"用户名修改成功: {old_username} -> {new_username} (UID: {uid})")
        return {"status": "ok", "new_username": new_username}
        
    except Exception as e:
        print(f"修改用户名失败: {e}")
        return {"status": "fail", "error": str(e)}, 500
    finally:
        conn.close()

# ===== 修改密码 =====
@app.route("/change_password", methods=["POST", "OPTIONS"])
def change_password():
    if request.method == "OPTIONS":
        return "", 200
    
    conn = db_manager.get_users_connection()
    cursor = conn.cursor()
    try:
        data = request.json
        uid = data.get("uid")
        old_password = data.get("old_password")
        new_password = data.get("new_password")
        
        if not uid or not old_password or not new_password:
            return {"status": "fail", "error": "参数不完整"}, 400
        
        # 验证用户
        cursor.execute("SELECT username, password FROM users WHERE uid=?", (uid,))
        user = cursor.fetchone()
        if not user:
            return {"status": "fail", "error": "用户不存在"}, 404
        
        # 验证旧密码
        if user[1] != old_password:
            return {"status": "fail", "error": "原密码错误"}, 401
        
        # 更新密码
        cursor.execute("UPDATE users SET password=? WHERE uid=?", 
                      (new_password, uid))
        conn.commit()
        
        print(f"密码修改成功: {user[0]} (UID: {uid})")
        return {"status": "ok", "message": "密码修改成功"}
        
    except Exception as e:
        print(f"修改密码失败: {e}")
        return {"status": "fail", "error": str(e)}, 500
    finally:
        conn.close()

@app.route("/avatar/<identifier>")
def get_avatar(identifier):
    conn = db_manager.get_users_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT avatar FROM users WHERE uid=? OR username=?", 
                      (identifier, identifier))
        result = cursor.fetchone()
        
        if result and result[0]:
            avatar_path = os.path.join("avatars", result[0])
            if os.path.exists(avatar_path):
                return send_from_directory("avatars", result[0])
        
        default_path = os.path.join("avatars", "default.png")
        if os.path.exists(default_path):
            return send_from_directory("avatars", "default.png")
    except Exception as e:
        print(f"获取头像失败: {e}")
    finally:
        conn.close()
    
    return {"error": "头像不存在"}, 404

@app.route("/upload_avatar", methods=["POST", "OPTIONS"])
def upload_avatar():
    if request.method == "OPTIONS":
        return "", 200
    
    conn = db_manager.get_users_connection()
    cursor = conn.cursor()
    try:
        identifier = request.form.get("username")
        if not identifier:
            return {"error": "未指定用户"}, 400
        
        cursor.execute("SELECT uid, username FROM users WHERE uid=? OR username=?", 
                      (identifier, identifier))
        user = cursor.fetchone()
        if not user:
            return {"error": "用户不存在"}, 404
        
        uid = user[0]
        username = user[1]
        
        if "avatar" not in request.files:
            return {"error": "没有文件"}, 400
        
        file = request.files["avatar"]
        if file.filename == "":
            return {"error": "未选择文件"}, 400
        
        if not file.content_type or not file.content_type.startswith("image/"):
            return {"error": "只能上传图片文件"}, 400
        
        file.seek(0, 2)
        size = file.tell()
        file.seek(0)
        if size > MAX_AVATAR_SIZE:
            return {"error": f"头像不能超过{MAX_AVATAR_SIZE//1024//1024}MB"}, 400
        
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
            return {"error": "不支持的图片格式"}, 400
        
        filename = f"{uid}_avatar{ext}"
        save_path = os.path.join("avatars", filename)
        
        cursor.execute("SELECT avatar FROM users WHERE uid=?", (uid,))
        result = cursor.fetchone()
        if result and result[0]:
            old_avatar = os.path.join("avatars", result[0])
            if os.path.exists(old_avatar) and result[0] != "default.png":
                try:
                    os.remove(old_avatar)
                except:
                    pass
        
        file.save(save_path)
        cursor.execute("UPDATE users SET avatar=? WHERE uid=?", (filename, uid))
        conn.commit()
        
        print(f"用户 {username} (UID: {uid}) 头像上传成功: {filename}")
        return {"filename": filename, "status": "success"}
        
    except Exception as e:
        print(f"上传头像失败: {e}")
        return {"error": str(e)}, 500
    finally:
        conn.close()

@app.route("/history")
def history():
    conn = db_manager.get_messages_connection()
    cursor = conn.cursor()
    try:
        before = request.args.get("before", type=int)
        
        if before:
            cursor.execute("""
                SELECT * FROM messages WHERE id<? 
                ORDER BY id DESC LIMIT 20
            """, (before,))
        else:
            cursor.execute("SELECT * FROM messages ORDER BY id DESC LIMIT 20")
        
        rows = cursor.fetchall()
        rows.reverse()
        
        result = []
        for r in rows:
            msg = json.loads(r[3])
            msg["id"] = r[0]
            msg["uid"] = r[1]
            msg["username"] = r[2]
            result.append(msg)
        
        return jsonify(result)
    except Exception as e:
        print(f"获取历史消息失败: {e}")
        return jsonify([])
    finally:
        conn.close()

@app.route("/emojis")
def emoji_list():
    try:
        emojis = os.listdir("emojis")
        image_extensions = ['.png', '.jpg', '.jpeg', '.gif', '.webp']
        emojis = [f for f in emojis if os.path.splitext(f)[1].lower() in image_extensions]
        return jsonify(emojis)
    except Exception as e:
        print(f"加载表情失败: {e}")
        return jsonify([])

@app.route("/emoji/<name>")
def emoji_file(name):
    return send_from_directory("emojis", name)

@app.route("/upload", methods=["POST", "OPTIONS"])
def upload():
    if request.method == "OPTIONS":
        return "", 200
        
    try:
        if "file" not in request.files:
            return {"error": "没有文件"}, 400
            
        file = request.files["file"]
        
        file.seek(0, 2)
        size = file.tell()
        file.seek(0)
        
        if size > MAX_FILE_SIZE:
            return {"error": f"文件不能超过{MAX_FILE_SIZE//1024//1024}MB"}, 400
        
        filename = file.filename
        name, ext = os.path.splitext(filename)
        counter = 1
        while os.path.exists(os.path.join("uploads", filename)):
            filename = f"{name}_{counter}{ext}"
            counter += 1
        
        save_path = os.path.join("uploads", filename)
        file.save(save_path)
        print(f"文件上传成功: {filename} ({size} bytes)")
        
        return {"filename": filename}
    except Exception as e:
        print(f"上传文件失败: {e}")
        return {"error": str(e)}, 500

@app.route("/file/<name>")
def file_download(name):
    return send_from_directory("uploads", name)

# ===== WebSocket =====
clients = set()

async def chat(websocket):
    clients.add(websocket)
    print(f"新客户端连接，当前在线: {len(clients)}")
    
    users_conn = db_manager.get_users_connection()
    msgs_conn = db_manager.get_messages_connection()
    msgs_cursor = msgs_conn.cursor()
    
    try:
        welcome_msg = {
            "type": "system",
            "content": "欢迎加入聊天室",
            "time": datetime.now().timestamp() * 1000
        }
        await websocket.send(json.dumps(welcome_msg))
        print("已发送欢迎消息")
        
        async for message in websocket:
            try:
                msg = json.loads(message)
                
                uid = msg.get("uid")
                username = msg.get("user")
                
                if not uid:
                    users_cursor = users_conn.cursor()
                    users_cursor.execute("SELECT uid FROM users WHERE username=?", (username,))
                    user_row = users_cursor.fetchone()
                    if user_row:
                        uid = user_row[0]
                    else:
                        uid = "unknown"
                
                print(f"收到消息: {msg.get('type')} 来自 {username} (UID: {uid})")
                
                msgs_cursor.execute("""
                    INSERT INTO messages (uid, username, data, timestamp) 
                    VALUES (?, ?, ?, ?)
                """, (uid, username, json.dumps(msg), int(time.time())))
                msgs_conn.commit()
                
                msg["id"] = msgs_cursor.lastrowid
                msg["uid"] = uid
                
                dead_clients = set()
                for c in clients:
                    try:
                        await c.send(json.dumps(msg))
                    except Exception as e:
                        print(f"发送给客户端失败: {e}")
                        dead_clients.add(c)
                
                for c in dead_clients:
                    clients.remove(c)
                    
            except json.JSONDecodeError:
                print("无效的JSON消息")
            except Exception as e:
                print(f"处理消息失败: {e}")
                    
    except websockets.exceptions.ConnectionClosed as e:
        print(f"客户端正常断开: {e}")
    except Exception as e:
        print(f"WebSocket错误: {e}")
    finally:
        users_conn.close()
        msgs_conn.close()
        clients.remove(websocket)
        print(f"客户端断开，当前在线: {len(clients)}")

# ===== 启动HTTP服务器（使用gunicorn时这个函数不会被执行）=====
def run_http():
    try:
        print(f"HTTP服务器启动在 http://{SERVER_IP}:{HTTP_PORT}")
        print(f"本地访问: http://localhost:{HTTP_PORT}")
        app.run(host="0.0.0.0", port=HTTP_PORT, debug=False, use_reloader=False)
    except Exception as e:
        print(f"HTTP服务器启动失败: {e}")

# ===== 启动WebSocket服务器 =====
async def run_ws():
    try:
        print(f"WebSocket服务器启动在 ws://{SERVER_IP}:{WS_PORT}")
        async with websockets.serve(chat, "0.0.0.0", WS_PORT):
            await asyncio.Future()
    except Exception as e:
        print(f"WebSocket服务器启动失败: {e}")

# ===== 主程序入口 =====
if __name__ == "__main__":
    print("=" * 50)
    print(f"  聊天服务器 {SERVER_NAME} 启动")
    print("=" * 50)
    print(f"HTTP端口: {HTTP_PORT}")
    print(f"WebSocket端口: {WS_PORT}")
    print(f"本机IP: {SERVER_IP}")
    print(f"大厅地址: {LOBBY_URL}")
    print(f"UID长度: {UID_LENGTH}位数字")
    print("=" * 50)
    
    # 注册到大厅
    if register_lobby():
        heartbeat_thread = threading.Thread(target=heartbeat_loop, daemon=True)
        heartbeat_thread.start()
        print("心跳线程已启动")
    
    if CONFIG.get("auto_open_browser", True):
        webbrowser.open("http://localhost:8000")
    
    # 使用 multiprocessing 启动 HTTP 服务（确保在 systemd 环境下也能运行）
    from multiprocessing import Process
    import time
    
    def run_http_wrapper():
        """包装函数，确保 run_http 能正确执行"""
        run_http()
    
    # 启动 HTTP 服务（作为独立进程）
    http_process = Process(target=run_http_wrapper, daemon=True)
    http_process.start()
    print(f"HTTP服务进程已启动，PID: {http_process.pid}")
    time.sleep(1)  # 给 HTTP 一点启动时间
    
    # 启动 WebSocket 服务（在主线程中运行）
    try:
        asyncio.run(run_ws())
    except KeyboardInterrupt:
        print("\n服务器关闭")
        unregister_from_lobby()
        # 确保 HTTP 进程也被终止
        if 'http_process' in locals():
            http_process.terminate()
            http_process.join()
