# 聊天服务器部署包

## Windows 用户
1. 解压 `windows.zip`
2. 双击 `启动服务器.bat`
3. 首次运行会自动安装依赖
4. 修改 `config.json` 配置你的聊天室
5. 重新启动即可

## 配置文件说明
详见 `配置说明.md`

## 常用命令
- Windows: `启动服务器.bat` - 启动
- Windows: `停止服务器.bat` - 停止